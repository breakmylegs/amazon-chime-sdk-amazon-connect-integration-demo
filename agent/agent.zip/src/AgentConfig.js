  
export const AGENT_CCP_URL = 'https://cie-demo-banking.awsapps.com/connect/ccp-v2/chat';

export const AWS_REGION = 'eu-west-2';

// Check the invokeURL under the ChimeConnectIntegrationDemo CF template output tab
export const INVOKE_URL = 'https://jjqzjvd8o6.execute-api.eu-west-2.amazonaws.com/v0';

// Check the ChimeConnectDemoUserAccessKey under the ChimeConnectIntegrationDemo CF template output tab
export const ACCESS_KEY = 'AKIAXOSVHMJ7A4SB3XMS';

// Check the ChimeConnectDemoUserSecretKey under the ChimeConnectIntegrationDemo CF template output tab 
export const SECRET_KEY = 'rsdlVQEOviLSN2MlrwXFi2YUuHLpKJd8HKDjLOW0';